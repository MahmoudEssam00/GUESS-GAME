'use strict';

let secretNumber = Math.trunc(Math.random() * 10) + 1;
let score = 10;
let highscore = 0;

const message = function (mess) {
  document.querySelector('.message').textContent = mess;
};

document.querySelector('.check').addEventListener('click', function () {
  const guess = +document.querySelector('.guess').value;

  if (!guess) {
    message('must be number');
  } else if (guess == secretNumber) {
    document.querySelector('body').style.backgroundColor = 'green';
    message('correct number');
    if (score > highscore) {
      highscore = score;
      document.querySelector('.highscore').textContent = highscore;
      document.querySelector('.score').textContent = score;
    }
  } else if (guess !== secretNumber) {
    message(guess > secretNumber ? 'too high' : 'too low');
    score--;
    document.querySelector('.score').textContent = score;
    if (score < 1) {
      document.querySelector('body').style.backgroundColor = 'red';
      message('game over');
    }
  }
});
